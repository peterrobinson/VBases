var aliases=[
{key: "line", context:"commentary", alias:"Line"},
{key: "line", context:"menus", alias:""},
{topEntity:"GP", context:"all", alias:"General Prologue"},
{topEntity:"MI", context:"all", alias:"Miller's Tale"},
{topEntity:"L1", context:"all", alias:"Link 1"},
{topEntity:"L2", context:"all", alias:"Link 2"},
{topEntity:"RE", context:"all", alias:"Reeve's Tale"},
{topEntity:"CO", context:"all", alias:"Cook's Tale"},
{topEntity:"L3", context:"all", alias:"Link 3"},
{topEntity:"L4", context:"all", alias:"Link 4"},
{topEntity:"L5", context:"all", alias:"Link 5"},
{topEntity:"L6", context:"all", alias:"Link 6"},
{topEntity:"WBP", context:"all", alias:"Wife of Bath's Prologue"}
]